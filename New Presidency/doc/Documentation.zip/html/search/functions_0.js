var searchData=
[
  ['add_115',['add',['../classmodel_1_1_matrix.html#adfd068119622fb4e94cd0c9c9faa1b24',1,'model::Matrix']]],
  ['addserie_116',['addSerie',['../classview_1_1_graphic_line.html#a5c2d364c80fe612f515bb13e7f800513',1,'view::GraphicLine']]],
  ['addstate_117',['addState',['../classmodel_1_1_state_list.html#a9ba91f6bb970efa2f9982babb03bd375',1,'model::StateList']]]
];
