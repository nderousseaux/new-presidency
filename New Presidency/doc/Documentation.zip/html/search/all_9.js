var searchData=
[
  ['main_73',['Main',['../class_main.html',1,'']]],
  ['matrix_74',['Matrix',['../classmodel_1_1_matrix.html',1,'model.Matrix'],['../classmodel_1_1_matrix.html#a67fc3b87a02a01c053637c6eb61c47ce',1,'model.Matrix.Matrix()']]],
  ['matrixtitle_75',['MatrixTitle',['../classmodel_1_1_matrix_title.html',1,'model.MatrixTitle'],['../classmodel_1_1_matrix_title.html#ada7a9f7d64908dac32e8ae21fcda831a',1,'model.MatrixTitle.MatrixTitle()']]]
];
