var searchData=
[
  ['textual_5finterface_36',['Textual_Interface',['../classview_1_1_textual___interface.html',1,'view']]],
  ['textualview_37',['TextualView',['../classview_1_1_textual_view.html',1,'view']]]
];
