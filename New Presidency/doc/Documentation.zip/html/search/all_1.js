var searchData=
[
  ['budget_3',['Budget',['../classmodel_1_1_budget.html',1,'model.Budget'],['../classmodel_1_1_budget.html#a1c6aada4d59aac2cff48a8d8c309f62d',1,'model.Budget.Budget()']]]
];
