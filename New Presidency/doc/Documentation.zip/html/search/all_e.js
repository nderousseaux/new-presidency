var searchData=
[
  ['victoryvalidated_96',['victoryValidated',['../classcontroller_1_1_controller.html#aca7e129bd9577a87dd0f22f5ff93b1cb',1,'controller::Controller']]]
];
